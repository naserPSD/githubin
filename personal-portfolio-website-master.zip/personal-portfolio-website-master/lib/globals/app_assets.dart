class AppAssets {
  static String facebook = 'assets/images/face.png';
  static String github = 'assets/images/git.png';
  static String linkedIn = 'assets/images/in.png';
  static String insta = 'assets/images/insta.png';
  static String twitter = 'assets/images/twit.png';
  static String profile1 = 'assets/images/pro1.png';
  static String profile2 = 'assets/images/pro2.png';
  static String code = 'assets/images/coding.png';
  static String brush = 'assets/images/brush-stroke.png';
  static String analyst = 'assets/images/analytics.png';
  static String work1 = 'assets/images/work1.jpg';
  static String work2 = 'assets/images/work2.jpg';
  static String share = 'assets/images/share.png';
}
