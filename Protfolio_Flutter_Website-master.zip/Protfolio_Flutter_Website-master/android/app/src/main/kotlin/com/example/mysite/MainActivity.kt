package com.example.mysite

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
