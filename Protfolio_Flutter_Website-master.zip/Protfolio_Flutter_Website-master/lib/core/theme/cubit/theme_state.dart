part of 'theme_cubit.dart';

class ThemeState {
  final bool isDarkThemeOn;

  ThemeState({required this.isDarkThemeOn});
}
