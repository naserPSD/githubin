// const List<String> socialIconURL = [
//   "https://img.icons8.com/fluency/48/000000/facebook-new.png",
//   // "https://img.icons8.com/color/48/000000/instagram-new--v1.png",
//   "https://img.icons8.com/color/48/000000/youtube-play.png",
//   "https://img.icons8.com/fluency/48/000000/twitter.png",
//   "https://img.icons8.com/color/48/000000/linkedin-circled--v1.png",
//   "https://img.icons8.com/external-tal-revivo-shadow-tal-revivo/48/000000/external-buy-me-a-coffee-help-creators-receive-support-from-their-audience-logo-shadow-tal-revivo.png",
//   "https://img.icons8.com/fluency/48/000000/github.png",
// ];

class IconUrls {
  static String upworkUrl =
      "https://img.icons8.com/external-tal-revivo-shadow-tal-revivo/48/000000/external-upwork-a-global-freelancing-platform-where-professionals-connect-and-collaborate-remotely-logo-shadow-tal-revivo.png";

  static String whatsappUrl =
      "https://img.icons8.com/color/48/000000/whatsapp--v1.png";

  static String fiverrUrl = "https://img.icons8.com/color/48/000000/fiverr.png";

  static const lightIcon = "https://img.icons8.com/ios/50/000000/sun--v1.png";
  static const darkIcon =
      "https://img.icons8.com/external-glyphons-amoghdesign/64/000000/external-moon-weather-vol-01-glyphons-amoghdesign.png";
}
