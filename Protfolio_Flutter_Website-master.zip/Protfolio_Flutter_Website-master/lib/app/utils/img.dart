class StaticImages {
  static const String hi = 'assets/hi.gif';
}
