// CV
const String resume =
    'https://drive.google.com/file/d/1bDNNrkQtNVJbXcdwMSx0crQQvAF_nMwV/view?usp=sharing';

// Github Link
const String gitHub = 'https://github.com/sudeshnb';
// Github Link
const String facebook = 'https://facebook.com/sudeshnb';
// Github Link
const String twitter = 'https://twitter.com/sudesh78';
// Github Link
const String youtube =
    'https://www.youtube.com/channel/UCXooUY2oL_eqGhTaZn-ExSg';
// Github Link
const String linkedin = 'https://linkedin.com/in/sudeshnb';
// Github Link
const String buymeacoffee = 'https://www.buymeacoffee.com/sudeshnb';
// Github Link
const String instagram = 'https://instagram.com/sudesh_nish';
// socialLinks
// const List<String> socialLinks = [
//   "https://facebook.com/sudeshnb",
//   // "https://instagram.com/sudesh_nish",
//   "https://www.youtube.com/channel/UCXooUY2oL_eqGhTaZn-ExSg",
//   "https://twitter.com/sudesh78",
//   "https://linkedin.com/in/sudeshnb",
//   "https://www.buymeacoffee.com/sudeshnb", "https://github.com/sudeshnb",
// ];
//
const String profileImage =
    "https://images.unsplash.com/photo-1503443207922-dff7d543fd0e?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=627&q=80";
//
// Github Link
const String fiverr = 'https://www.fiverr.com/sudeshnb';
// Github Link
const String upwork = 'https://www.upwork.com/freelancers/~015c46144016569e31';
// Github Link
const String whatsapp = 'https://api.whatsapp.com/send?phone=94741325674';
