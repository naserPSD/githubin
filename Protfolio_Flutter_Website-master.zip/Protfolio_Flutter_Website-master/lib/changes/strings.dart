String hellotag = '''Hi there, Welcome to My Space  ''';

String yourname = "I'm Sudesh Bandara,";
// String hometitle2 = "A Mobile Application\nDeveloper";

String animationtxt1 = " Mobile Application Developer";
String animationtxt2 = " UI/UX Designer";
String animationtxt3 = " Web Developer";

//
String contactHeadding = "Let’s try my service now!";
String contactSubHeadding =
    "Let’s work together and make everything super cute and super useful.";
//
String miniDescription =
    "Freelancer providing services for programming and design content needs. Join me down below and let's get started!";

String servicesSubHeading =
    "Since the beginning of my journey as a freelance designer and developer, I've worked in startups and collaborated with talented people to create digital products for both business and consumer use. I offer a wide range of services, including brand design, programming and teaching.";
//

String protfolioSubHeading =
    "Since the beginning of my journey as a designer and developer, I have created digital products for business and consumer use. This is a little bit.";
const String aboutMeHeadline =
    'I\'m Sudesh Bandara, a Mobile App developer, Web developer and UI designer.';

const String aboutMeDetail =
    'I\'m a Fresh Graduate as Software Engineer from Quanrt University, UK. I have been developing mobile apps for over 4 years now. I have worked in teams for various startups and helped them in launching their prototypes and got valuable learning experience. Been a CEO/Co-Founder of Onyxsio, Sri Lanka. Currently working as an Associate Software Engineer at Onyxsio.';
