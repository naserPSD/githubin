import 'package:flutter/material.dart';
import 'my_site.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MySite());
}
